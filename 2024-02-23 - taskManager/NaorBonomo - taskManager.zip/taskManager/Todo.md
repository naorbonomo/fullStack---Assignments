# Task manager notes board

- [x] board img background
- [x] big title img / styled text
- [x] input form 
    - [x] note info
    - [x] note due date
    - [x] note due time
    - [x] submit form to new note
    - [x] clear form



## stickers /Notes

- [x] notes add from left to right
- [x] fade-in effect (transitions)
- [x] text MUST stay inside note sticker, if bigger use scroller
- [x] time and date show at the bottom left of note (*maybe sticky somehow)
- [x] "X" button to close/delete note in top right corner. show only with mouse over.
- [x] use "Glyph Icon" from Bootstrap (not regular img)
- [x] delete note from screen and local storage.

